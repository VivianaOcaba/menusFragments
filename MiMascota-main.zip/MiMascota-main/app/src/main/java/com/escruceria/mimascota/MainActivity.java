package com.escruceria.mimascota;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

import com.escruceria.mimascota.Mascota;
import com.escruceria.mimascota.MascotaAdapter;
import com.escruceria.mimascota.MascotasFavoritasActivity;
import com.escruceria.mimascota.R;


public class MainActivity extends AppCompatActivity {

    ArrayList<Mascota> mascotas;
    private RecyclerView rvMascotas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar); // <- ESTA línea debe ir aquí

        rvMascotas = findViewById(R.id.rvMascotas);
        rvMascotas.setLayoutManager(new LinearLayoutManager(this));

        inicializarListaMascotas();
        MascotaAdapter adapter = new MascotaAdapter(mascotas);
        rvMascotas.setAdapter(adapter);
    }

    private void inicializarListaMascotas() {
        mascotas = new ArrayList<>();
        mascotas.add(new Mascota("Brandy", R.mipmap.ic_perro1_foreground, 5));
        mascotas.add(new Mascota("Minus", R.mipmap.ic_gato_foreground, 3));
        mascotas.add(new Mascota("Zeus", R.mipmap.ic_perro2_foreground, 7));
        mascotas.add(new Mascota("Federico", R.mipmap.ic_loro_foreground, 4));
        mascotas.add(new Mascota("Estrella", R.mipmap.ic_periquito_foreground, 2));
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_favoritos) {
            Intent intent = new Intent(this, MascotasFavoritasActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

