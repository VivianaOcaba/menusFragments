package com.escruceria.mimascota;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MascotasFavoritasActivity extends AppCompatActivity {

    private ArrayList<Mascota> mascotasFavoritas;
    private RecyclerView rvFavoritas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mascotas_favoritas);

        rvFavoritas = findViewById(R.id.rvFavoritas);
        rvFavoritas.setLayoutManager(new LinearLayoutManager(this));

        mascotasFavoritas = new ArrayList<>();
        mascotasFavoritas.add(new Mascota("Zeus", R.mipmap.ic_perro2_foreground, 7));
        mascotasFavoritas.add(new Mascota("Brandy", R.mipmap.ic_perro1_foreground, 5));
        mascotasFavoritas.add(new Mascota("Minus", R.mipmap.ic_gato_foreground, 3));
        mascotasFavoritas.add(new Mascota("Federico", R.mipmap.ic_loro_foreground, 4));
        mascotasFavoritas.add(new Mascota("Estrella", R.mipmap.ic_periquito_foreground, 2));

        MascotaAdapter adapter = new MascotaAdapter(mascotasFavoritas);
        rvFavoritas.setAdapter(adapter);
    }
}
